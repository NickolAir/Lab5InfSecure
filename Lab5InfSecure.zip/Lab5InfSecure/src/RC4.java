import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class RC4 {
    // Метод для RC4-шифрования
    public static byte[] rc4(byte[] key, byte[] data) {
        // Инициализация перестановочного массива
        int[] S = new int[256];
        for (int i = 0; i < 256; i++) {
            S[i] = i;
        }

        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + S[i] + key[i % key.length]) & 0xFF;
            int temp = S[i];
            S[i] = S[j];
            S[j] = temp;
        }

        // Генерация псевдослучайной последовательности и шифрование
        int i = 0;
        j = 0;
        byte[] result = new byte[data.length];
        for (int k = 0; k < data.length; k++) {
            i = (i + 1) & 0xFF;
            j = (j + S[i]) & 0xFF;
            int temp = S[i];
            S[i] = S[j];
            S[j] = temp;
            int K = S[(S[i] + S[j]) & 0xFF];
            result[k] = (byte) (data[k] ^ K);
        }

        return result;
    }

    // Главный метод
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Введите строку для шифрования: ");
            String message = scanner.nextLine();

            String keyString = "secretkey"; // Ключ шифрования
            byte[] key = keyString.getBytes();
            byte[] data = message.getBytes();

            // Шифрование
            byte[] encrypted = rc4(key, data);
            System.out.println("Зашифрованное: " + new String(encrypted));

            // Расшифрование
            byte[] decrypted = rc4(key, encrypted);
            System.out.println("Расшифрованное: " + new String(decrypted));
        } catch (Exception e) {
            System.err.println("Ошибка: " + e.getMessage());
        }
    }
}