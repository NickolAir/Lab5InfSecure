import java.nio.ByteBuffer;
import java.util.Arrays;

public class Skipjack {
    public static void main(String[] args) {
        // Пример ключа для шифрования (массив из 10 байт)
        byte[] key = new byte[] { (byte) 0x1F, (byte) 0x2A, (byte) 0x3B, (byte) 0x4C,
                (byte) 0x5D, (byte) 0x6E, (byte) 0x7F, (byte) 0x8A,
                (byte) 0x9B, (byte) 0xAC };

        // Пример значения для шифрования
        int originalValue = 0x12345678;  // Пример 32-битного значения

        // Шифруем
        int encryptedValue = Skip32.encrypt(originalValue, key);
        System.out.println("Encrypted value: " + Integer.toHexString(encryptedValue));

        // Расшифровываем
        int decryptedValue = Skip32.decrypt(encryptedValue, key);
        System.out.println("Decrypted value: " + Integer.toHexString(decryptedValue));

        // Проверяем, совпадает ли расшифрованное значение с исходным
        if (originalValue == decryptedValue) {
            System.out.println("Test passed! The decrypted value matches the original.");
        } else {
            System.out.println("Test failed! The decrypted value does not match the original.");
        }
    }
}
