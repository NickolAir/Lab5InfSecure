import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SHA256 {
    public static String calculateHash(String filePath) throws NoSuchAlgorithmException, IOException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (FileInputStream fis = new FileInputStream(filePath)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                digest.update(buffer, 0, bytesRead);
            }
        }

        // Конвертация байтового массива в строку (hex)
        StringBuilder hashValue = new StringBuilder();
        for (byte b : digest.digest()) {
            hashValue.append(String.format("%02x", b));
        }
        return hashValue.toString();
    }

    public static void main(String[] args) {
        String filePath = "/Users/nikolayratushnyak/IdeaProjects/Lab5InfSecure/src/example.json";
        try {
            String hash = calculateHash(filePath);
            System.out.println("Хеш файла " + filePath + ": " + hash);
        } catch (IOException | NoSuchAlgorithmException e) {
            System.err.println("Ошибка: " + e.getMessage());
        }
    }
}